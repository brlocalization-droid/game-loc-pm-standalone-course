# 🎮 Game Loc PM — From Kickoff to Gold Master

An interactive, gamified course on **game localization project management**, built with an 8-bit RPG aesthetic. Bilingual: English and Brazilian Portuguese.

![Game Loc PM Screenshot](https://img.shields.io/badge/modules-10-39d353?style=flat-square&labelColor=0d1117) ![Lessons](https://img.shields.io/badge/lessons-50-58a6ff?style=flat-square&labelColor=0d1117) ![Languages](https://img.shields.io/badge/languages-EN%20%7C%20PT--BR-d2a8ff?style=flat-square&labelColor=0d1117) ![License](https://img.shields.io/badge/license-MIT-e3b341?style=flat-square&labelColor=0d1117)

## What is this?

A **zero-video, fully interactive** course that teaches you how to manage game localization projects — from ecosystem fundamentals to audio production, firefighting, and career growth.

Everything runs in a single HTML file. No backend. No login. No video hosting. Just open and learn.

## Features

- **10 Modules, 50 Lessons** covering the full game loc PM lifecycle
- **RPG Progression**: XP, 10 levels (Intern → Game Loc Master), 19 achievements
- **3 Mini-Games**: Term Match, Risk Spotter, Speed Round
- **Boss Fight Quizzes** after each module with instant feedback
- **Quest Rewards**: Real-world deliverables (templates, trackers, checklists)
- **Bilingual**: Full EN/PT-BR toggle on every screen
- **8-bit Aesthetic**: Chiptune sound effects, pixel art UI, scanline overlay
- **Persistent Progress**: Saves to localStorage across sessions
- **Single HTML File**: No dependencies, no build step, works offline

## Modules

| # | Module | Lessons | Topics |
|---|--------|---------|--------|
| 01 | 🌍 The Ecosystem | 5 | Industry players, PM role, service models, content types, game dev lifecycle |
| 02 | 🔬 Project Anatomy | 5 | Core components, scale (indie vs AAA), parallel workflows, sim-ship, live-service |
| 03 | 🛠️ PM Toolbox | 5 | CAT tools, BMS systems, communication, trackers, automation |
| 04 | 💰 Quoting | 5 | Units, file analysis, timeline math, pricing models, quote defense |
| 05 | 🚀 Kickoff | 5 | Kickoff meetings, reference kits, queries, vendor briefing, engineering alignment |
| 06 | ⚡ Production | 5 | Standard workflow, vendor management, daily ops, change management, delivery |
| 07 | 🛡️ Quality (LQA) | 5 | LQA vs QA, error models, LQA process, bug reporting, quality metrics |
| 08 | 🎙️ Audio Loc | 5 | Audio pipeline, casting, studio logistics, lip-sync, audio QA |
| 09 | 🔥 Firefighting | 5 | Top 10 problems, risk management, vendor emergencies, crisis comms, post-crisis |
| 10 | 🏆 Post-Delivery | 5 | Post-mortems, TM maintenance, account growth, career path, personal brand |

## Quick Start

Just open `index.html` in any modern browser. That's it.

```bash
# Clone and open
git clone https://github.com/YOUR_USERNAME/game-loc-pm-course.git
cd game-loc-pm-course
open index.html
```

Or host it anywhere that serves static files (GitHub Pages, Netlify, Vercel, S3).

## Deploy to GitHub Pages

1. Go to your repo **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: `main`, folder: `/ (root)`
4. Your course will be live at `https://YOUR_USERNAME.github.io/game-loc-pm-course/`

## Tech Stack

- React 18 (CDN, no build step)
- Babel Standalone (in-browser JSX compilation)
- Web Audio API (chiptune sound effects)
- localStorage (persistent progress)
- Zero external dependencies beyond React CDN

## Contributing

Issues and PRs welcome. The course content lives in the `MODULES` array inside `index.html`. Each module has `en` and `pt` variants with lessons, quizzes, and deliverables.

## License

MIT — use it, fork it, sell it, teach with it.
